package demo.app;

import java.io.IOException;
import java.net.URLDecoder;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.InternalAuthenticationServiceException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.GenericFilterBean;

public class AuthenticationFilter extends GenericFilterBean {

	private final static Logger LOGGER = LoggerFactory.getLogger(AuthenticationFilter.class);

	private AuthenticationManager authenticationManager;

	public AuthenticationFilter(final AuthenticationManager authenticationManager) {
		super();
		this.authenticationManager = authenticationManager;
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		LOGGER.info("Inside authentication filter.");

		HttpServletRequest httpRequest = ((HttpServletRequest) request);

		if(httpRequest.getRequestURI().indexOf("loginviapath") != -1) {
			String url = URLDecoder.decode(httpRequest.getRequestURI(),"utf-8").replace("/loginviapath/", "");
			url = url.replaceAll("\"", "");
			tryToAuthenticate(new UsernamePasswordAuthenticationToken(url.split("/")[0], url.split("/")[1]));
		}
		chain.doFilter(request, response);
	}

	private Authentication tryToAuthenticate(Authentication requestAuthentication) {
		Authentication responseAuthentication = authenticationManager.authenticate(requestAuthentication);
		if (responseAuthentication == null || !responseAuthentication.isAuthenticated()) {
			throw new InternalAuthenticationServiceException(
					"Unable to authenticate Domain User for provided credentials");
		}
		logger.debug("User successfully authenticated");
		SecurityContextHolder.getContext().setAuthentication(responseAuthentication);
		return responseAuthentication;
	}

}
